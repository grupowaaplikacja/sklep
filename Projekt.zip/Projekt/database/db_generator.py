from database import db
db.create_all()