$(window).on('scroll', function () {
  if ($(window).scrollTop()) {
    $('nav').addClass('black');
  } else {
    $('nav').removeClass('black');
  }
})






$(".drop")
  .mouseover(function () {
    $(".dropdown").show(300);
  });
$(".drop")
  .mouseleave(function () {
    $(".dropdown").hide(300);
  });




$(document).ready(function () {
  $('#toTopButton').hide();
  $(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
      $('#toTopButton').fadeIn(500);
    }
    else {
      $('#toTopButton').fadeOut(500);
    }
  });
  $('#toTopButton').click(function () {
    $('html, body').animate({ scrollTop: 0 }, 1000);
    return false;
  });
});


$(".menu").on('mousemove', function(event) {
  var menuOffset = ((((event.pageY/window.innerHeight) * 100) / 5) - 10) * -1;
  $(this).css({'transform' : 'translateY(' + menuOffset + '%)'});
});





var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function currentDiv(n) {
  showDivs(slideIndex = n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  if (n > x.length) { slideIndex = 1 }
  if (n < 1) { slideIndex = x.length }
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
            /*for (i = 0; i < dots.length; i++) {
              dots[i].className = dots[i].className.replace(" w3-red", "");
            }
            */
    x[slideIndex - 1].style.display = "block";
  /*dots[slideIndex-1].className += "w3-red";*/
}


