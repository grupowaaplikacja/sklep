/*
*
* Sidebar
*
*/

function w3_open() {
  document.getElementById("main").style.marginLeft = "20%";
  document.getElementById("mySidebar").style.width = "20%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
  document.getElementById("top").style.height = "170px"; 
  document.getElementById("main").style.width = "80%";
  document.getElementById("footer").style.width = "100%";
  document.getElementById("img-product-all").style.marginTop = "90px";
 
  
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
  document.getElementById("main").style.width = "100%";
  document.getElementById("top").style.height = "200px";
  document.getElementById("footer").style.width = "100%";
  document.getElementById("openNav").style.display = "block";
}

function myAccFunc() {
    var x = document.getElementById("demoAcc");
    if (x.className.indexOf("w3-show") == -1) {
      x.className += " w3-show";
      x.previousElementSibling.className += " w3-blue";
    } else { 
      x.className = x.className.replace(" w3-show", "");
      x.previousElementSibling.className = 
      x.previousElementSibling.className.replace(" w3-blue", "");
    }
  }
  
  

/*
*
*
*
*/

$(document).ready(function () {
  $('#toTopButton').hide();
  $(window).scroll(function () {
    if ($(this).scrollTop() > 100) {
      $('#toTopButton').fadeIn(500);
    }
    else {
      $('#toTopButton').fadeOut(500);
    }
  });
  $('#toTopButton').click(function () {
    $('html, body').animate({ scrollTop: 0 }, 1000);
    return false;
  });
});
  
