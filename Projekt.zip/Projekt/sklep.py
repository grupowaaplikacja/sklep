# -*- coding: utf-8 -*-
# sklep.py

from flask import *
import datetime
import os
import sqlite3
from database.database import *
import uuid
from werkzeug.utils import secure_filename

app = Flask(__name__)

app.config.update(dict(
    SECRET_KEY='bardzosekretnawartosc',
    DATABASE=os.path.join(app.root_path, 'database/database.db'),
))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/zaloguj')
def zaloguj():
    return render_template('loguj.html')
	
@app.route('/rejestracja')
def rejestracja():
    return render_template('rejestruj.html')
	
@app.route('/index3')
def index3():
    return render_template('index3.html')

	

@app.route('/index4/<kategoria>')
def pokaz_kategorie(kategoria):
	if(kategoria == 'nowosci'):
		produkty=Product.query.order_by(Product.id.desc()).all()
	else:
		produkty=Product.query.filter_by(category=kategoria).all()
	ile = len(produkty)
	kat = kategoria.replace('_', ' ').upper()
	return render_template('index4.html', produkty=produkty, kategoria = kat)

@app.route('/produkt/<kod>')
def produkt(kod):
	produkt = Product.query.filter_by(unique_id=kod).first()
	return render_template('produkt.html', produkt=produkt)

@app.route('/regulamin')
def regulamin():
    return render_template('regulamin.html')

@app.route('/kontakt')
def kontakt():
    return render_template('kontakt.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port='20000')